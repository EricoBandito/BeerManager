package com.example.beermanager.Classes;

public class Player {
    String playerName;
    String playerType;

    public Player(String name, String type) {
        playerName = name;
        playerType = type;
    }
}
